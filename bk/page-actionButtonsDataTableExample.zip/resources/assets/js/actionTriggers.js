(function() {
    'use strict';

    angular
        .module('bonitasoft.ui.extensions')
        .service('bonitaService', bonitaService);

    function bonitaService($log) {

        return {
			trigger1: trigger1,
			trigger2: trigger2
        };

        function trigger1(first, second) {
            alert("ALERT: " + first + second);
        }

        function trigger2(first, second) {
			return "SHOW " + first + " " + second;
        }
    }

})();